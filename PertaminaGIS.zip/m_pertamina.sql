-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2021 at 04:12 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbpertamina`
--

-- --------------------------------------------------------

--
-- Table structure for table `m_pertamina`
--

CREATE TABLE `m_pertamina` (
  `id` int(11) NOT NULL,
  `nama` varchar(2555) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `alamat` varchar(2555) NOT NULL,
  `photo` varchar(2555) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `m_pertamina`
--

INSERT INTO `m_pertamina` (`id`, `nama`, `latitude`, `longitude`, `alamat`, `photo`) VALUES
(1, 'SPBU Pertamina 54.803.07', -8.78373248910524, 115.1882133995168, 'Jl. Bypass Ngurah Rai No.30X, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipMOwvzaNYOSA4BCi2tSGJ8gROdpQgpG8byZpnaA=w426-h240-k-no'),
(2, 'SPBU Pertamina 54.803.02', -8.76958446103995, 115.1781006131448, 'Jl. Bypass Ngurah Rai No.6, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', 'https://www.google.co.id/maps/place/SPBU+Pertamina+54.803.02/@-8.7703095,115.1782235,3a,75y,90t/data=!3m8!1e2!3m6!1sAF1QipMItezqBolHv92mgvkq9TGxa9iIJm9Phauyel-T!2e10!3e12!6shttps:%2F%2Flh5.googleusercontent.com%2Fp%2FAF1QipMItezqBolHv92mgvkq9TGxa9iIJm9Phauyel-T%3Dw203-h406-k-no!7i2080!8i4160!4m9!1m2!2m1!1spertamina+di+kuta+selatan!3m5!1s0x2dd2447cb977c1cb:0x34826a470b165f5a!8m2!3d-8.7702268!4d115.1781651!15sChlwZXJ0YW1pbmEgZGkga3V0YSBzZWxhdGFuIgOIAQGSAQtnYXNfc3RhdGlvbg#'),
(3, 'SPBU Pertamina 54.803.10', -8.780839362110614, 115.17474937149106, 'Jl. Uluwatu II No.10, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipPAWpE6Ol-3YDPQLHPAnmGT5zirCjXd78p9fk64=w426-h240-k-no'),
(4, 'SPBU Pertamina Nusa Dua', -8.792549375238485, 115.21514216880615, 'Gg. Permata, Benoa, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipNlXLQqnKpXZm0osMja0sbeEXMqq8qsUos2PcUH=w408-h306-k-no'),
(5, 'SPBU Pertamina 54.803.25', -8.783942531257503, 115.19723893807563, 'Jl. Bypass Ngurah Rai No.30X, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', 'https://www.google.co.id/maps/place/SPBU+Pertamina+54.803.25/@-8.7848968,115.1968527,3a,75y,90t/data=!3m8!1e2!3m6!1sAF1QipOu6ksqFy26VmfRSm6oxJR-mxhwpczTHCF_Z-Ke!2e10!3e12!6shttps:%2F%2Flh5.googleusercontent.com%2Fp%2FAF1QipOu6ksqFy26VmfRSm6oxJR-mxhwpczTHCF_Z-Ke%3Dw86-h114-k-no!7i3024!8i4032!4m9!1m2!2m1!1spertamina+di+kuta+selatan!3m5!1s0x2dd24364eee14763:0x578d4cd5bdb02000!8m2!3d-8.7847058!4d115.1968577!15sChlwZXJ0YW1pbmEgZGkga3V0YSBzZWxhdGFuIgOIAQGSAQtnYXNfc3RhdGlvbg#'),
(6, 'SPBU Pertamina Darma Wangsa', -8.805512330412535, 115.20134356085659, 'Jalan Darma Wangsa, Benoa, Kuta Selatan, Benoa, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipMY7AeyXZhp0PY-DdWn-GrOmYJ3I9vHkkRSXwyr=w408-h302-k-no'),
(7, 'SPBU Pertamina 54.803.27', -8.791121005141143, 115.21466492222353, 'Jl. By Pas Ngurah Rai, Benoa, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipNvEp1V_fjLoAT8x6Evco8G2O8T6zVJwT08wnWM=w408-h306-k-no'),
(8, 'SPBU Pertamina 54.803.16', -8.796786522700245, 115.16101083812269, 'Jl. Raya Uluwatu No.45xx, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipNL9juexvf5j00ncLhALcab3h3AsA1CQa5eBWnA=w408-h306-k-no'),
(9, 'SPBU Pertamina 54.803.28', -8.782607215781212, 115.18666886880614, 'Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipOqduKpt8azGp6KbKHHfyKPwf0qnIlwyvdeaCBY=w408-h306-k-no'),
(10, 'SPBU Pertamina Ungasan', -8.818003550771657, 115.15052901793678, 'Jl. Raya Uluwatu No.75X, Ungasan, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipNIVo0P4kEoXg3DaC5VxM5-m9D0XGdi7qN22Dtp=w426-h240-k-no'),
(11, 'SPBU Pertamina Bandara I Gusti Ngurah Rai', -8.742344123303678, 115.17545039865027, 'Jl. Airport Ngurah Rai No.800, Tuban, Kuta, Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipM7R7ZRP3WDnhba71e_OQrXETS8EXO9FxNR4u4=w408-h306-k-no'),
(12, 'SPBU Pertamina KFC Gelael', -8.720657745280048, 115.1802329918224, 'Jl. Raya Kuta No.103, Kuta, Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipNhTUO_ci_wmGW6qmGEkWMiRn7Cyoq6pxvt7li0=w423-h240-k-no'),
(13, 'SPBU Pertamina Sunset Road', -8.714711720916084, 115.1863652190205, 'Jl. Sunset Road, Seminyak, Kuta, Kabupaten Badung, Bali 80361', 'https://streetviewpixels-pa.googleapis.com/v1/thumbnail?panoid=D9P9f5jZ6lrRPe-N_WKUFw&cb_client=search.gws-prod.gps&w=408&h=240&yaw=19.36177&pitch=0&thumbfov=100'),
(14, 'SPBU Pertamina 54.803.20', -8.701246187187204, 115.17546635291284, 'Jl. Dewi Sri No.7 A, Legian, Kuta, Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipOFonPbMT9KqYXWUTRx8mYuApoTkAW8quo0L81i=w426-h240-k-no'),
(15, 'SPBU Pertamina 54.803.34', -8.697907476043452, 115.17810363927194, 'Jalan Sunset Road, Legian, Kuta, Legian, Kuta, Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipPMB_LLPd3yjrJGOyoQpR5hoSxD0D4ul5C2TEyC=w408-h306-k-no'),
(16, 'SPBU Pertamina Seminyak', -8.688240864046756, 115.17169752527955, 'Jalan Sunset Road, Seminyak, Kuta, Seminyak, Kuta, Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipM9UbWTmvBRg-S44uJdaMWFvMV4ZGeP4cRntKJP=w426-h240-k-no'),
(17, 'SPBU Pertamina 54.803.06', -8.672817706774364, 115.16517985766973, 'Jalan Raya Kerobokan, Kuta, Kerobokan Kelod, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipP0T9jYpW-6xGw8vdnESSn8K3-qos5qyiLODmj0=w408-h306-k-no'),
(18, 'SPBU Pertamina Teuku Umar Barat', -8.67333235631505, 115.17783000693578, 'Jl. Teuku Umar Barat, Kerobokan Kelod, Kec. Kuta Utara, Kabupaten Badung, Bali 80117', 'https://lh5.googleusercontent.com/p/AF1QipOEACh0gONMgvlHuxyO9tsJnFriy6A05g1wXQfu=w408-h306-k-no'),
(25, 'SPBU Pertamina Canggu', -8.643694331890014, 115.16061167370738, 'Jl. Raya Canggu, Kerobokan, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipNlQCMfB-J6P2HvdliejirluQGS6WVgIOMJcfd6=w408-h306-k-no'),
(26, 'SPBU Pertamina 54.803.09', -8.636990661711174, 115.17408709148795, 'Jl. Raya Kerobokan No.888, Kerobokan Kaja, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipPpIiwIyhHTR8vrUTkJ8F6QrPvIeuQ2pUXOamsh=w408-h726-k-no'),
(27, 'SPBU Pertamina 54.801.44', -8.636580111048593, 115.17709761058357, 'Jl. Gatot Subroto Barat No.47, Kerobokan Kaja, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipOyLBLIC0CfXfR8HPni47lgiND29gPmHJRwIG98=w426-h240-k-no'),
(28, 'SPBU Pertamina 54.803.22', -8.62895316762408, 115.17283065371959, 'Jl. Tegal Permai No.2, Kerobokan Kaja, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://lh5.googleusercontent.com/p/AF1QipP_WhNfdpXHlLi0gpSDCt51kEK2b9d7nZpiY8ol=w408-h306-k-no'),
(29, 'SPBU Pertamina Lukluk', -8.593306658852253, 115.18602618472391, 'Jl. Raya Lukluk No.221, Lukluk, Kec. Mengwi, Kabupaten Badung, Bali 80351', 'https://lh5.googleusercontent.com/p/AF1QipPJosq3Wrp1LRWL0fLEI1qoewKFq5VTsVaeOx0b=w423-h240-k-no'),
(30, 'SPBU Pertamina Abianbase', -8.601156669500352, 115.1714468924856, 'Jalan Raya Dalung, Dalung, Kuta Utara, Dalung, Kec. Kuta Utara, Kabupaten Badung, Bali 80351', 'https://lh5.googleusercontent.com/p/AF1QipMIqJowBlpjEYkf1cIX9Kp29W4zITvuzFp1uezj=w426-h240-k-no');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `m_pertamina`
--
ALTER TABLE `m_pertamina`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `m_pertamina`
--
ALTER TABLE `m_pertamina`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
