package com.mobile.pertaminagis;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ImageView Group = (ImageView) findViewById(R.id.user);

        Group.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Home.this, UserActivity.class);
                startActivity(intent);
            }
        });
        ImageView Search = (ImageView) findViewById(R.id.cari);

        Search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pindahpeta = new Intent(Home.this, MapsActivity.class);
                startActivity(pindahpeta);
            }
        });
        ImageView Desc = (ImageView) findViewById(R.id.desk);

        Desc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Home.this, DeskActivity.class);
                startActivity(intent);
            }
        });
    }
}

